yum -y install tcmu-runner targetcli-fb
systemctl enable target
systemctl start target
targetcli
